# Nathan Loudon - Resume and Portfolio

## DESCRIPTION

Resume and Portfolio for Nathan Loudon

## TECHNOLOGIES USED


    React
    AWS/SLS
    GraphQL
    Lambda



