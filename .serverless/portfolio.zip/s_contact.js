
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'vesnathan',
  applicationName: 'portfolio',
  appUid: 'xL1XZ0pmCBT4hG0wcp',
  orgUid: '1148429b-dd9f-46a8-a186-9e9ba192d45e',
  deploymentUid: 'e1cf7085-d062-452c-9a01-0715536125dc',
  serviceName: 'portfolio',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'portfolio-dev-contact', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.contact, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}