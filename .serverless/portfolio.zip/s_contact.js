
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'vesnathan',
  applicationName: 'portfolio',
  appUid: 'xL1XZ0pmCBT4hG0wcp',
  orgUid: '1148429b-dd9f-46a8-a186-9e9ba192d45e',
  deploymentUid: '31338c7e-28e5-4eb8-853c-21f1edd61275',
  serviceName: 'portfolio',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'portfolio-dev-contact', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.contact, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}